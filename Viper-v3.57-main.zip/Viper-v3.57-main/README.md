# Viper-v3.57
   ## Hi there 👋

<h1 align="center">ꪶVIPER V3ꫂ<br></h1>
<p align="center">
<img src="https://i.imgur.com/A8LuCoD.jpeg" />
</p>

<p align="center">
Viper-v3.57 𝘽𝙤𝙩 is a bug bot from badboi and gabby created by <a href="king Badboi 👑" target="_blank">Gabby</a> using <a href="https://github.com/adiwajshing/Baileys" target="_blank">Baileys</a> and <a href="https://github.com/nodejs" target="_blank">Nodejs</a>. Dont forget to give a star bro.
</p>
<p align="center">
  <a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=EB+Garamond&weight=800&size=28&duration=4000&pause=1000&random=false&width=435&lines=+_____Viper+v3_____;WHATSAPP+CRASH+x+BUG+BOT;DEVELOPED+BY+BAD+BOI;REALESE+DATE+14%2F7%2F2024." alt="Typing SVG" /></a>
</p>

### 1. <a href="https://github.com/RAGNAROK-BOY/Viper-v3.57/fork"><img src="https://img.shields.io/badge/FORK-Red" alt="Click Here to fork Viper-v3" width="70"></a>
## `Generate Pair Code For Session`
 
[`Viper-v3 Pairing Using Render`](https://gabby-session-cred.onrender.com)

[`Viper-v3 Pairing using Replit`](https://replit.com/@belugadev53/Viper-v357?s=app)
<p align="center">
   
   <a href="https://github.com/RAGNAROK-BOY">
    <img src="https://i.imgur.com/9f8ucRW.jpeg" width="500">
     
</a>
 <p align="center"><img src="https://profile-counter.glitch.me/{RAGNAROK-BOY}/count.svg" alt="xcelsama:: Visitor's Count" /></p>



[`ℹ️Contact Gabby`](https://wa.me/233276895312)

FORK MY REPO WILL YA

### . <a href="https://pylexnodes.net"><img src="https://img.shields.io/badge/DEPLOY ON PANEL-black" alt="Click Here to Deploy on Panel" width="130"></a>

### . <a href="https://dashboard.toystack.ai/login"><img src="https://img.shields.io/badge/DEPLOY ON TOYSTACK AI -black" alt="Click Here to Deploy on TOYSTACK AI" width="130"></a>

Now Deploy
    <br>
Instalasi
## Heroku Buildpack
```bash
heroku/nodejs
```
```
https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest
```
```
https://github.com/clhuang/heroku-buildpack-webp-binaries.git
```

*Add your Creds.json to Session file
* Create a new app at [Heroku](https://id.heroku.com/login)
* Add Build packs
* Connect your heroku with your github
* Locate Viper v3.56
* Now deploy.
* Start the Worker
* Enjoy the Bot.
  
### 4. <a 
#### DEPLOY TO RENDER

 ★ Register To Render 
    <br>
<a href='https://dashboard.render.com/register' target="_blank"><img alt='Render' src='https://img.shields.io/badge/CREATE-h?color=black&style=for-the-badge&logo=render' width="96.35" height="28"/></a></p>

★ Now Deploy
    <br>
<a href='https://dashboard.render.com/select-repo?type=web' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/DEPLOY -h?color=black&style=for-the-badge&logo=render' width="96.35" height="28"/></a></p>

</br>

#### COPY THESE COMMANDS AND PASTE IF YOU TRYING TO DEPLOY [Viper-v3.56](https://github.com/RAGNAROK-BOY/Viper-v3.57) ON ANY TERMINAL
```
sudo apt -y update && sudo apt -y upgrade
```
```
sudo apt -y install git ffmpeg curl
```
```
curl -fsSL https://deb.nodesource.com/setup_20.x -o nodesource_setup.sh
```
```
sudo -E bash nodesource_setup.sh
```
```
sudo apt-get install -y nodejs
```
```
sudo npm install -g yarn
```
```
sudo yarn global add pm2
```
```
git clone https://github.com/type-your-username-here/Viper v3.56
```
```
cd Viper v3.56
```
```
yarn install
```
```
npm start
```
 

[`HERE'S AN EXAMPLE OUTPUT`](https://wasi-session-test-2d5de70f8522.herokuapp.com)
# `Owner`

 <a href="https://github.com/RAGNAROK-BOY"><img src="https://github.com/RAGNAROK-BOY.png" width="250" height="250" alt=" GABBY"/></a>


